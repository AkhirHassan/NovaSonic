const { BedrockRuntimeClient, ConverseStreamCommand } = require('@aws-sdk/client-bedrock-runtime');

const client = new BedrockRuntimeClient({ region: 'us-east-1' });

exports.handler = async (event) => {
    console.log('=== LEX NOVA SONIC LAMBDA START ===');
    console.log('Full Lex Event:', JSON.stringify(event, null, 2));
    
    try {
        // Handle Lex V2 event format
        const customerInput = event.inputTranscript || event.transcriptions?.[0]?.transcription || 'Hello';
        
        console.log('Customer input:', customerInput);
        console.log('Event keys:', Object.keys(event));
        
        // Prepare Claude 3 Haiku request
        const request = {
            modelId: 'anthropic.claude-3-haiku-20240307-v1:0',
            messages: [
                {
                    role: 'user',
                    content: [{
                        text: customerInput
                    }]
                }
            ],
            system: [{
                text: 'You are a helpful AI assistant. Keep responses conversational and under 100 words.'
            }],
            inferenceConfig: {
                maxTokens: 200,
                temperature: 0.7
            }
        };
        
        console.log('Sending request to Claude 3 Haiku...');
        const command = new ConverseStreamCommand(request);
        const response = await client.send(command);
        
        let aiResponse = '';
        for await (const chunk of response.stream) {
            if (chunk.contentBlockDelta?.delta?.text) {
                aiResponse += chunk.contentBlockDelta.delta.text;
            }
        }
        
        console.log('Claude 3 Haiku response:', aiResponse);
        
        // Return Lex V2 response format
        return {
            sessionState: {
                dialogAction: {
                    type: 'Close'
                },
                intent: {
                    name: event.sessionState?.intent?.name || 'FallbackIntent',
                    state: 'Fulfilled'
                }
            },
            messages: [
                {
                    contentType: 'PlainText',
                    content: aiResponse || 'I understand. How else can I help you?'
                }
            ]
        };
        
    } catch (error) {
        console.error('Error details:', error);
        console.error('Error message:', error.message);
        console.error('Error stack:', error.stack);
        return {
            sessionState: {
                dialogAction: {
                    type: 'Close'
                },
                intent: {
                    name: event.sessionState?.intent?.name || 'FallbackIntent',
                    state: 'Failed'
                }
            },
            messages: [
                {
                    contentType: 'PlainText',
                    content: 'Sorry, I encountered an error. Please try again.'
                }
            ]
        };
    }
};