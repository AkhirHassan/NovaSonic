const { BedrockRuntimeClient, ConverseStreamCommand } = require('@aws-sdk/client-bedrock-runtime');

const client = new BedrockRuntimeClient({ region: 'us-east-1' });

exports.handler = async (event) => {
    console.log('=== NOVA SONIC LAMBDA START ===');
    console.log('Full Connect Event:', JSON.stringify(event, null, 2));
    
    try {
        const details = event.Details;
        const parameters = details.Parameters;
        const customerInput = parameters.customerInput || 'Hello';
        
        console.log('Customer input:', customerInput);
        
        // Prepare Nova Sonic request
        const request = {
            modelId: 'amazon.nova-sonic-v1:0',
            messages: [
                {
                    role: 'user',
                    content: [{
                        text: customerInput
                    }]
                }
            ],
            system: [{
                text: 'You are a helpful AI assistant. Keep responses conversational and under 100 words.'
            }],
            inferenceConfig: {
                maxTokens: 200,
                temperature: 0.7
            }
        };
        
        console.log('Sending request to Nova Sonic...');
        const command = new ConverseStreamCommand(request);
        const response = await client.send(command);
        
        let aiResponse = '';
        for await (const chunk of response.stream) {
            if (chunk.contentBlockDelta?.delta?.text) {
                aiResponse += chunk.contentBlockDelta.delta.text;
            }
        }
        
        console.log('Nova Sonic response:', aiResponse);
        
        return {
            statusCode: 200,
            response: aiResponse || 'I understand. How else can I help you?'
        };
        
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 200,
            response: 'Sorry, I encountered an error. Please try again.'
        };
    }
};